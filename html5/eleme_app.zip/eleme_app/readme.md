- 工作流 
  scripts 强化我们的开发
  dev  启化我们的http 服务 
  styl stylus 编译为css 
  json-server  商家信息 
- dom api 是过去式
  MVVM {{}}   js  data: 
  历史  切图仔  php/java + html/css 10年前 <%= message%> 前端不需要了解数据后端 
  js 8年前 web 2.0 fetch / ajax js 主动请求数据
  前后端分庭搞礼 DOM/ api 
  4年前 vue/react + node + flutter(客户端) + GO + docker   时代 MVVM 时代 连数据也要处理 

  小程序和vue 都是一样一样的， 
  mvvm 优秀的地方在于 简单 
  - 天生集成数据驱动  data {{}} :src
  - 页面是响应式的 数据变了， 界面就会变 