<template>
  <div>
    Goods
  </div>
</template>
