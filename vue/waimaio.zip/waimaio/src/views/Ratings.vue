<template>
  <div>
    Ratings
  </div>
</template>
